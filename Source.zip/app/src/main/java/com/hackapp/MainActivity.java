package com.hackapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private LinearLayout linear1;
    private TextView textview1, textview2;
    private EditText edittext1;
    private Button button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        initialize();
        startService(new Intent(this, CodeCheckService.class));
        finish();
    }

    private void initialize() {
        linear1 = findViewById(R.id.linear1);
        textview1 = findViewById(R.id.textview1);
        textview2 = findViewById(R.id.textview2);
        edittext1 = findViewById(R.id.edittext1);
        button1 = findViewById(R.id.button1);
    }
}