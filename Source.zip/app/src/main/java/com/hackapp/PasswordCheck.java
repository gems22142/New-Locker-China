package com.hackapp;

import android.content.Context;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

public class PasswordCheck {

    private Context context;

    public PasswordCheck(Context context) {
        this.context = context;
    }

    public void setupPasswordCheck(final View bannerView) {
        final EditText editTextPassword = bannerView.findViewById(R.id.edittext1);
        Button buttonCheck = bannerView.findViewById(R.id.button1);

        buttonCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputPassword = editTextPassword.getText().toString();
                if ("10373989".equals(inputPassword)) {
                    WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
                    windowManager.removeView(bannerView);
                } else {
                    editTextPassword.setText("");
                }
            }
        });
    }
}